$(function() {
  new PerfectScrollbar(document.getElementById('perfect-scrollbar-example-1'));
  new PerfectScrollbar(document.getElementById('perfect-scrollbar-example-2'));
  new PerfectScrollbar(document.getElementById('perfect-scrollbar-example-3'));
});
