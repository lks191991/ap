$(function() {
  $('.datatables-demo').dataTable();
});
